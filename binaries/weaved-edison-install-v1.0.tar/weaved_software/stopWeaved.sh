systemctl stop weavedSSH.service
systemctl stop weavedHTTP.service
echo
ps | grep weaved

