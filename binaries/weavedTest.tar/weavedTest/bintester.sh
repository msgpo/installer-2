#!/bin/sh 

for file in weavedConnectd.*; do
	result="$(./$file  2> log.txt)"
	if grep -qi error log.txt; then
	echo "." > /dev/null
	else
		echo "-----------------------"
		echo "$file works. " 
	fi
done
