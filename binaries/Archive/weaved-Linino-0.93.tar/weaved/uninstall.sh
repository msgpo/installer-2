#!/bin/sh
#set -x
echo "Weaved secure connection services for Linino"
read -p "Do you want to uninstall Weaved software? (Yy/Nn)" resp
if [ "$resp" == "y" ] || [ "$resp" = "Y" ]; then

if [ -e /etc/init.d/weavedWEB ]
then
/etc/init.d/weavedWEB stop
/etc/init.d/weavedWEB disable
rm /etc/init.d/weavedWEB
fi

if [ -e /etc/init.d/weavedSSH ]
then
/etc/init.d/weavedSSH stop
/etc/init.d/weavedSSH disable
rm /etc/init.d/weavedSSH
fi

if [ -e /usr/bin/weavedConnectd ]
then
rm /usr/bin/weavedConnectd
fi

rm -rf /etc/weaved

for i in scripts/*
do
   file=$(echo $i | awk -F '\/' '{ print $2 }')

   if [ -e "/usr/bin/$file" ] 
   then
   echo "Removing /usr/bin/$file"
   rm "/usr/bin/$file"
   fi
done

echo " "
echo "Weaved services uninstalled."
echo " "
fi
