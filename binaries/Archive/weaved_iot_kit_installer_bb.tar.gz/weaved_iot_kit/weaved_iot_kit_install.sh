#!/bin/bash

CMD_SUCCEED=0

ERR_USER=1
ERR_CD=2
ERR_FILE=3
ERR_UPDATE_FILE=4
ERR_UPDATE_KEY=5
ERR_UPDATE=6
ERR_INSTALL=7
ERR_CONFIG=8


#### check for Installed files  #####################

if [ ! -s /etc/weaved/services/http.conf ]
then 
	echo "/etc/weaved/services/http.conf : file is not available"
	echo "Install/Reinstall the weaved services package"
	exit $ERR_FILE
fi

if [ ! -s /etc/init.d/weavedConnectd ]
then 
	echo "/etc/init.d/weavedConnectd: file is not available"
	echo "Install/Reinstall the weaved services package"
	exit $ERR_FILE
fi

if [ ! -s /usr/bin/weavedConnectd ]
then 
	echo "/usr/bin/weavedConnectd: file is not available"
	echo "Install/Reinstall the weaved services package"
	exit $ERR_FILE
fi

if [ ! -s /usr/bin/notify.sh ]
then 
	echo "/usr/bin/notify.sh: file is not available"
	echo "Install/Reinstall the weaved services package"
	exit $ERR_FILE
fi
###############################################################

#Update the package index.

sudo apt-get update
if [ "$?" != "$CMD_SUCCEED" ]
then
	echo "failed to Update the package index."
	exit $ERR_UPDATE
fi

#### is weavedConnectd deamon is up and running ##############

sudo ps -ef | grep -v grep | grep weavedConnectd >> /dev/null
if [ "$?" -eq 1 ]
then
	sudo service weavedConnectd start
fi

echo "weavedConnectd Daemon is running .."

echo "Installing LAMP Package.."

#### Install rest of LAMP Stack ##############################

sudo apt-get install apache2 php5 libapache2-mod-php5

#sudo apt-get install mysql-server mysql-client php5-mysql

sudo service apache2 restart

if [ ! -s /var/www ]
then
        echo "/var/www: directory unavailable"
        echo "cannot install Weaved_iot"
	echo "ReInstall apache2 and try again"
        exit $ERR_FILE
fi

if [ -s /var/www/index.html ]
then
## if default index.html exists, save it
   sudo service apache2 stop
   sudo mv /var/www/index.html /var/www/default_index.html
fi

##### Install the Weaved_Web_Setup ############################

sudo cp ./send_notification.sh  /usr/bin/send_notification.sh
sudo chmod +x /usr/bin/send_notification.sh

## If this is to be default page uncomment Section-I below
sudo cp ./index.php /var/www/index.php
sudo mkdir /var/www/Images
sudo cp  logo.png /var/www/Images/
sudo cp  pc.gif /var/www/Images/

####  Check for web interface #################################

if [ ! -s /var/www/index.php ] || [ ! -s /var/www/Images/pc.gif ] || [ ! -s /var/www/Images/logo.png ] || [ ! -s /usr/bin/send_notification.sh ]
then
	echo "Files missing for weaved iot kit install"
	echo "Reinstall the package : Weaved IoT Kit Installer"
	exit $ERR_FILE
fi

sudo service apache2 restart
###############################################################

echo "Weaved IoT Kit Successfully Installed"

exit $CMD_SUCCEED
