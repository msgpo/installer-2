#!/bin/bash

#### Run to uninstall Weaved iot kit ########

sudo rm /usr/bin/send_notification.sh
sudo rm /var/www/index.php
sudo rm -r /var/www/Images

