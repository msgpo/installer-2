<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <!--meta name="viewport" content = " height= device-height, width = 920, user-scalable = yes/-->
        <meta name="viewport" content = "user-scalable = no/>
        <!--meta name="viewport" content = "width = 920, user-scalable = no" /-->
        <title>Your Device Notification Page</title>

        <style>
        body {
            background-color:#0088AA;
	    font-color=#00DCDC; font-size:120px; font-family:'DejaVu Sans'
        }

        p {
            font-color:#FFFFFF; font-size:40px; font-family:'DejaVu Sans';
        }

		p.small {
			line-height: 5%;
			margin-top:-1px;
		}

		.div {
            background-color:#007EA0;
            height : 1000;
            width : 620;
        }

		.button {
			cursor:pointer;background-color:#38474C; -moz-border-radius:15px;-webkit-border-radius:10px;
			box-shadow:0 0 4px rgba(0,0,0, .75); float:bottom; font-size: 58px; line-height: 30px; 
			font-family: 'Comic Sans MS', Geneva, Verdana, Arial, Helvetica, sans-serif; font-weight:none;
			height:100px; width:840px; color:#FFFFFF; border:1px solid transparent;
		}

        </style>
    </head>


<body class="body">

	<center><img src="/Images/logo.png" style="width:400px; height:160px" alt="Image not found" align="middle" /></center>
	<center> <img src="/Images/pc.gif" style="width:800px; height:480px" alt="Image not found" align="middle" /> </center>

	<br>
	<center> <form name="Run_Notify" method="post" action="">
			 <input type="submit"class="button" name="Notify_Button" value="Send Me a Push Alert" /> </form></center>

	<br>
	<br>

</body>

<?php
	if(isset($_POST['Notify_Button']))
	{
		$output = shell_exec('sh /usr/bin/send_notification.sh "0" "Hello World" "ok" &');

	#        echo "<pre><center>$output</center></pre>";
	}
?>

</html>
