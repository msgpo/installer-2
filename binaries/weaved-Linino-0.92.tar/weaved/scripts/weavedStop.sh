/etc/init.d/weavedWEB stop
/etc/init.d/weavedSSH stop
