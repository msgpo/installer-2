/etc/init.d/weavedWEB start
/etc/init.d/weavedSSH start
